export default class Followers {
  // Your code here
}